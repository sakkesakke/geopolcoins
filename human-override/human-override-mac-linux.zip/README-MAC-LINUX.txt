MINDVETO for Mac and Linux - the AI kill switch
(c) 2026 Amghar Said. All rights reserved.

Blocks AI chatbots and AI tools in EVERY browser and app on this computer.

1. Unzip, open Terminal in this folder.
2. Block AI:        sudo sh mindveto.sh on
3. Allow AI again:  sudo sh mindveto.sh off
Run "on" again any time to update the list. A backup of your hosts file is kept as /etc/hosts.human-override-backup.
More: https://mindveto.app/

TERMS OF USE: provided "as is", no guarantee that every AI is blocked; Amghar Said is not liable for any damage
or consequence of use to the maximum extent permitted by law. https://mindveto.app/terms/
