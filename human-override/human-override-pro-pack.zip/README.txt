HUMAN OVERRIDE PRO PACK - the AI kill switch for organisations
(c) 2026 Amghar Said. All rights reserved. Mindveto - the AI kill switch (formerly Human Override). https://mindveto.app/

For IT departments of courts, police, government, schools and companies that must keep AI chatbots and AI tools
off their network and devices. Domains: 161. Updated: 2026-11-13. Fresh copies: https://geopolcoins.xyz/human-override/pro/

Pick what fits your network (you can combine them):

1. Browser policy on every PC (no extension needed)
   chrome-edge-policy.json  -> Chrome and Edge policy "URLBlocklist" (Group Policy, Intune, Jamf or Google Admin).
   firefox-policies.json    -> put in the Firefox "distribution" folder or push via Group Policy ("WebsiteFilter").

2. DNS server (blocks every device and app on the network)
   rpz.zone                 -> BIND, PowerDNS, Infoblox, Knot (Response Policy Zone).
   windows-dns-server.ps1   -> Windows Server DNS (one query resolution policy).
   unbound.conf             -> Unbound, OPNsense, pfSense.
   dnsmasq.conf             -> dnsmasq, OpenWrt, Pi-hole.

3. Proxy and firewall
   squid-acl.conf           -> Squid proxy.
   firewall-edl.txt         -> External Dynamic List / threat feed for Palo Alto, Fortinet, Check Point, Sophos and others.

Honest limits: DNS and firewall lists block whole domains; AI built into allowed services, AI running offline on a
device, and traffic over a VPN or another DNS (DNS-over-HTTPS) can bypass them. Block outside DNS/DoH and VPNs on your
firewall for full effect. Test in a pilot group first.

Family filter (optional, not AI): adult-content lists in the same formats at https://geopolcoins.xyz/human-override/adult/
(hosts.txt, domains.txt, adblock.txt; MIT-licensed sources, see NOTICE.txt there). SafeSearch on a DNS server:
answer google.com/www.google.<tld> with CNAME forcesafesearch.google.com, www.bing.com with strict.bing.com,
duckduckgo.com with safe.duckduckgo.com and www.youtube.com/m.youtube.com/youtubei.googleapis.com with restrict.youtube.com.
Anti-bypass (optional): web proxies, VPN services, Tor and secure-DNS (DoH/DoT) addresses at
https://geopolcoins.xyz/human-override/bypass/ (same formats). Also block outgoing port 853 (DoT) and set the browser
policy DnsOverHttpsMode = off (Chrome/Edge) or DNSOverHTTPS Enabled=false (Firefox).

Terms of use (provided "as is", limits of liability): https://mindveto.app/terms/
Help with roll-out: hello@mindveto.app · https://mindveto.app/network/
